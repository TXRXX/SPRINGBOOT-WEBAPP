package Tree;

public class Balsam_Fir extends Tree{
	public Balsam_Fir() {
		name = "Balsam Fir";
	}
	@Override
	public double cost() {
		return 5;
	}

}
