package Tree;

public class BlueSpruce extends Tree {
	public BlueSpruce() {
		name = "Colorado Blue Spruce";
	}
	@Override
	public double cost() {
		return 20;
	}

}
