package Tree;

public class Douglas_Fir extends Tree{

	public Douglas_Fir() {
		name = "Douglas Fir";
	}
	@Override
	public double cost() {
		return 15;
	}

}
