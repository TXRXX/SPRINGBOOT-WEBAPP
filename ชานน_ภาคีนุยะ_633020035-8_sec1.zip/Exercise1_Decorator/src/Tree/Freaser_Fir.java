package Tree;

public class Freaser_Fir extends Tree {
	
	public Freaser_Fir() {
		//Tree.name
		name = "Freaser Fir";
	}
	@Override
	public double cost() {
		return 12;
	}

}
